
import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { createSession, loadProfile } from "../lib/session";
import questionsData from "../public/questions.json";

export default function StartPracticeModal({ open, onClose }) {
  const [mounted, setMounted] = useState(false);
  const [container, setContainer] = useState(null);
  const [subject, setSubject] = useState("");
  const [chapter, setChapter] = useState("");
  const [level, setLevel] = useState("Easy");
  const [grade, setGrade] = useState(null);

  useEffect(()=>{
    setMounted(true);
    const c = document.createElement("div");
    document.body.appendChild(c);
    setContainer(c);
    const profile = loadProfile();
    if (profile && profile.standard) setGrade(String(profile.standard));
    const prev = document.body.style.overflow;
    document.body.style.overflow = open ? "hidden" : prev;
    return () => {
      document.body.style.overflow = prev;
      if (c && c.parentNode) c.parentNode.removeChild(c);
    };
  },[]);

  useEffect(()=>{
    if (!mounted) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = open ? "hidden" : prev;
    return () => { document.body.style.overflow = prev; };
  },[open, mounted]);

  const subjects = useMemo(()=>{
    const subs = new Set(questionsData.map(q=>q.subject));
    return Array.from(subs);
  },[]);

  const chapters = useMemo(()=>{
    const list = questionsData.filter(q => {
      const okSub = subject ? q.subject===subject : true;
      const okGrade = grade ? String(q.standard)===String(grade) : true;
      return okSub && okGrade;
    }).map(q=>q.chapter);
    return Array.from(new Set(list));
  },[subject, grade]);

  useEffect(()=>{
    if (!subject && subjects.length) setSubject(subjects[0]);
  },[subjects, subject]);

  useEffect(()=>{
    if (chapters.length && !chapters.includes(chapter)) setChapter(chapters[0]);
  },[chapters, chapter]);

  function start() {
    if (!subject || !chapter || !level) return;
    createSession({
      subject,
      standard: grade || "",
      chapter,
      level,
      questions: questionsData,
    });
    window.location.href = "/exam";
  }

  if (!open || !mounted || !container) return null;

  const content = (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/30" role="dialog" aria-modal="true">
      <div className="bg-white rounded-2xl p-4 w-[520px] max-w-[92vw] max-h-[80vh] overflow-auto shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold">Start New Practice</h3>
          <button onClick={onClose} className="px-2 py-1 rounded border" aria-label="Close">✕</button>
        </div>

        <p className="text-sm text-gray-600 mb-3">
          {grade ? <>Grade <b>{grade}</b></> : <>Select options below</>}. You’ll get <b>{process.env.NEXT_PUBLIC_QUESTIONS_PER_ROUND || 10}</b> questions.
        </p>

        <div className="grid grid-cols-2 gap-3">
          <label className="text-sm col-span-2">
            Subject
            <select className="w-full border rounded p-2" value={subject} onChange={e=>setSubject(e.target.value)}>
              {subjects.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>

          <label className="text-sm col-span-2">
            Chapter
            <select className="w-full border rounded p-2" value={chapter} onChange={e=>setChapter(e.target.value)}>
              {chapters.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>

          <label className="text-sm col-span-2">
            Level
            <select className="w-full border rounded p-2" value={level} onChange={e=>setLevel(e.target.value)}>
              {["Easy","Medium","Hard"].map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </label>
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <button className="px-3 py-2 rounded border" onClick={onClose}>Cancel</button>
          <button className="px-3 py-2 rounded bg-blue-600 text-white disabled:opacity-50" onClick={start} disabled={!subject || !chapter || !level}>
            Start
          </button>
        </div>
      </div>
    </div>
  );

  return createPortal(content, container);
}
