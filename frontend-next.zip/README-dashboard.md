# Dashboard upgrades applied. Install recharts and run dev.
