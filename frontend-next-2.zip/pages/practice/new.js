
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import questionsData from "../../public/questions.json";
import { createSession, loadProfile } from "../../lib/session";

export default function NewPractice(){
  const router = useRouter();
  const [profile, setProfile] = useState(null);
  const [subject, setSubject] = useState("");
  const [chapter, setChapter] = useState("");
  const [level, setLevel] = useState("Easy");

  useEffect(()=>{
    const p = loadProfile();
    if(!p){ router.push("/"); return; }
    setProfile(p);
  },[]);

  const subjects = useMemo(()=> Array.from(new Set(questionsData.map(q=>q.subject))), []);

  const chapters = useMemo(()=>{
    const grade = profile ? String(profile.standard) : null;
    const list = questionsData.filter(q=>{
      const okSub = subject ? q.subject===subject : true;
      const okGrade = grade ? String(q.standard)===grade : true;
      return okSub && okGrade;
    }).map(q=>q.chapter);
    return Array.from(new Set(list));
  },[subject, profile]);

  useEffect(()=>{ if(!subject && subjects.length) setSubject(subjects[0]); },[subjects, subject]);
  useEffect(()=>{ if(chapters.length && !chapters.includes(chapter)) setChapter(chapters[0]); },[chapters, chapter]);

  function start(){
    if(!subject || !chapter || !level) return;
    createSession({ subject, standard: profile?.standard || "", chapter, level, questions: questionsData });
    router.push("/exam");
  }

  const defaultSize = Number(process.env.NEXT_PUBLIC_QUESTIONS_PER_ROUND || 10);

  return (
    <div className="container mx-auto p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-semibold">Start Practice</h1>
          {profile && <span className="px-2 py-1 rounded-full text-xs bg-blue-50 text-blue-700">Hi, {profile.name || "Student"} · Grade {profile.standard}</span>}
        </div>
        <Link href="/dashboard" className="text-sm underline">Back to Dashboard</Link>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl p-4 shadow bg-white">
          <div className="text-sm font-medium mb-1">Subject</div>
          <div className="grid grid-cols-2 gap-2">
            {subjects.map(s => (
              <button key={s} onClick={()=>setSubject(s)}
                className={\`border rounded-xl p-3 text-left \${subject===s?"bg-blue-600 text-white border-blue-600":"bg-white"}\`}>
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl p-4 shadow bg-white">
          <div className="text-sm font-medium mb-1">Level</div>
          <div className="flex gap-2">
            {["Easy","Medium","Hard"].map(l=>(
              <button key={l} onClick={()=>setLevel(l)}
                className={\`border rounded-full px-4 py-2 \${level===l?"bg-green-600 text-white border-green-600":"bg-white"}\`}>
                {l}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-600 mt-2">You’ll get <b>{defaultSize}</b> questions.</p>
        </div>

        <div className="rounded-2xl p-4 shadow bg-white md:col-span-2">
          <div className="text-sm font-medium mb-2">Chapter</div>
          {chapters.length ? (
            <div className="grid md:grid-cols-3 gap-2">
              {chapters.map(c => (
                <button key={c} onClick={()=>setChapter(c)}
                  className={\`border rounded-xl p-3 text-left \${chapter===c?"bg-indigo-600 text-white border-indigo-600":"bg-white"}\`}>
                  {c}
                </button>
              ))}
            </div>
          ) : (
            <div className="text-sm text-gray-500">No chapters found for this subject/grade.</div>
          )}
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="container mx-auto p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm">
            <span className="font-medium">Selection:</span>{" "}
            {subject || "—"} · {chapter || "—"} · {level || "—"}
          </div>
          <div className="flex gap-2">
            <Link href="/dashboard" className="px-3 py-2 rounded border">Cancel</Link>
            <button onClick={start} disabled={!subject || !chapter || !level}
              className="px-4 py-2 rounded bg-blue-600 text-white disabled:opacity-50">Start</button>
          </div>
        </div>
      </div>
    </div>
  );
}
